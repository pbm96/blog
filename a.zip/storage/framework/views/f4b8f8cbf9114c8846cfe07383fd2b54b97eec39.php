<?php $__env->startSection('titulo_pagina', 'Acceder'); ?>
<?php $__env->startSection('estilos'); ?>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>

    <!-- Material form login -->
    <div class="container mt-5 pt-5">
        <div class="row justify-content-center">
            <div class="col-sm-6">
                <div class="card">

                    <h5 class="card-header  text-center py-4 negro_principal" >
                        <strong>Acceder</strong>
                    </h5>

                    <!--Card content-->
                    <div class="card-body px-lg-5 pt-0 ">

                        <!-- Form -->
                        <form class="text-center" method="POST" style="color: #757575;" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <!-- Email -->
                            <div class="md-form">
                                <input id="email" type="email"
                                       class="form-control<?php echo e($errors->has('email') ? ' invalid' : ''); ?>" name="email"
                                       value="<?php echo e(old('email')); ?>" required autofocus>
                                <label for="email">E-mail</label>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                            <?php endif; ?>


                            <!-- Password -->
                                <div class="md-form">
                                    <input id="password" type="password"
                                           class="form-control<?php echo e($errors->has('password') ? ' invalid' : ''); ?>"
                                           name="password" required>
                                    <label for="password">Password</label>
                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="d-flex justify-content-around">
                                <div>
                                    <!-- Remember me -->
                                    <div class="form-check ">
                                        <input class="form-check-input" type="checkbox" name="remember"
                                               id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="remember">Recordarme</label>
                                    </div>
                                </div>
                                <div>

                                    
                                    <a href="<?php echo e(route('register')); ?>" class="">No estas Registrado? <strong class="text-info">REGISTRATE</strong></a>
                                </div>
                            </div>

                            <!-- Sign in button -->
                            <div class="row justify-content-center">
                            <button class="btn btn-outline-info btn-rounded btn-block my-4 col-sm-4 waves-effect z-depth-0"
                                    type="submit">Acceder
                            </button>
                            </div>


                        </form>
                        <!-- Form -->

                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- Material form login -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>